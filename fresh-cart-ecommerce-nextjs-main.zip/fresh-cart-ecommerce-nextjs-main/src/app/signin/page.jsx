import SignIn from '@/components/05SignIn/SignIn';
import React from 'react'

export const metadata = {
  title: "Sign In",
  description: "Sign In",
};

export default function page() {
  return (
    <SignIn />
  )
}
