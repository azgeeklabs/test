import SignUp from '@/components/04SignUp/SignUp';
import React from 'react'

export const metadata = {
  title: "Sign Up",
  description: "Sign Up",
};

export default function page() {

  return (
    <SignUp />
  )
}

